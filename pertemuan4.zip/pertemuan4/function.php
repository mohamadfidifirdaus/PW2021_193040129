<?php 

	function salam($waktu, $nama) {
	   return "Selamat $waktu, $nama";
	}

?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Latihan Fuction</title>
	</head>
	<body>
	<h1><?php echo salam("Pagi", "FIDI"); ?> </h1>
	
	</body>
	</html>



 