<?php 
	
	// Date
	// Untuk menampilkan tanggal dengan format tertentu
	echo date("l, d-M-Y <br><br>") ;


	// Time
	// Unix timestamp / EPOCH time
	// Detik yang sudah berlalu sejak 1 Januari 1970
	echo time();

	echo date("d-M-Y", time()+172800);

	//mktime
	//membuat sendiri detik
	//mktime(0,0,0,0,0)
	//jam, menit, detik, bulan, tanggal, tahun
	// echo date("l", mktime(0,0,0,0,8,25,1985));


	//strtotime
	echo strtotime("25 aug 1985");


 ?>