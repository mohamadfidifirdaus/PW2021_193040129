<?php 

//pengkodisian atau percabangan 
// if else
// if else if else
// ternary
// switch


$x = 2;
if ($x < 20) {
	echo "BENAR!";
} else if ($x == 20) {
	echo "BINGO!!!";
} 
else {
	echo "SALAH";
}


?>