<?php 

// Pengulangan
// for
// while
// do...while
// foreach : pengulangan khusus array


//ini adalah contoh for

for ($i=0; $i < 5; $i++) { 
	echo "Hello World! <br>";
}


//ini adalah cotoh while

$i = 0;
while ($i < 5) {
	echo "<br>Hello World! <br>";

$i++;
}

//ini adalah do...while

$i = 0;
do {
	echo "<br>Hello World! ";
	$i++;
} while ($i < 5);




 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<title>Latihan 1</title>
 </head>
 <body>

 	<table border="1" cellspacing="10" cellpadding="0">
 		<?php 
 			for ($i=1; $i <= 3; $i++) { 
 				echo "<tr>";
 					for ($j=1; $j <= 5; $j++) { 
 						echo "<td>$i,$j</td>";
 					}

 				echo "</tr>";
 			}




 		 ?>



 	</table>
 
 </body>
 </html>